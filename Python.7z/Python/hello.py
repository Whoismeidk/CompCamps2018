name = "Mark"
age = 15

def sayhello(person):
    print("Welcome {}, I'm glad to meet you.".format(person))

print("My name is {} and I am {} years old.".format(name, age))

user = input("What is your name? ")
