from compcamps_cash_api.entities import Block, Transaction, Prefix, Keys
from compcamps_cash_api import CompCampsCashApi
import datetime as date
ccapi = CompCampsCashApi("https://compcamps-cash.herokuapp.com")

prefix = ccapi.getPrefix()
# Calls the keys class from the ccapi
myKeys = Keys()
public_key, _ = myKeys.getEncodedKeys()

def getPaid():
    transaction = Transaction("MINER", "AtpToaUoYJhj0FJH52TDxBPPSAhE0ai7DeaBDoAab0R5VPzETlSPIWGAw/T5bFF70ytzarHkX8yn3WhvU2rI9A==", 1)
    transaction.sign(myKeys)
    return transaction
while 1:
    transactions = ccapi.getPendingTransactions() # Gets the current transactions from the server

    nonce = 0
    previousBlock = ccapi.getCurrentBlock()

    block = Block(previousBlock.index + 1, transactions, nonce, previousBlock.hash)

    transactions.append(getPaid())

    currentTimestamp = date.datetime.now()
    while not block.validate(prefix):
        nonce = nonce + 1
        block = Block(previousBlock.index + 1, transactions, nonce, previousBlock.hash)
        if (date.datetime.now() - currentTimestamp).total_seconds() > 5:
            previousBlock = ccapi.getCurrentBlock()
            prefix = ccapi.getPrefix()
            transactions = ccapi.getPendingTransactions()
            transactions.append(getPaid())

    res = ccapi.postBlock(block)
    print(res)

if not block.validate(prefix):
    print("Invalid Hash.")
else:
    print("Correct hash!")
