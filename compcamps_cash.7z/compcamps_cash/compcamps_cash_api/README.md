# Campcoin
A blockchain in Python

## Installation
pip install -r requirements.txt 

## Execution
python main.py
